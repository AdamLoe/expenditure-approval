DROP TABLE users;
DROP TABLE requests;
DROP TABLE filters;
