console.log('88888888888888888888888888888');
console.log('booting up new lambda process');
console.log('88888888888888888888888888888');

exports.handler = (event, context, callback) => {
    console.log('---------Request Received--------');
    console.log('event', event);
    console.log('context', context);

    callback(null, 'Request Worked i guess');
}
