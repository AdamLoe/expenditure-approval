/**
 * Created by Adam on 4/13/2018.
 */
var x = !(true) || 'adam';
console.log(x);