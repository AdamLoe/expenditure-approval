module.exports = {
	path: "/",
	httpMethod: "GET",
	headers: {
		Authorization: ""
	},
	queryStringParameters: null,
	pathParameters: null,
	requestContext: {

	},
	body: null,
	isBase64Encoded: false
};