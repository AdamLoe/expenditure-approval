/*
	auth.js
	------------
	We pass our username and access_token in our basic-auth headers
	From there we check if our access_token is valid and timely
 */

var knex = require("./knexfile.js");

var basicAuth = require("basic-auth");

//Using a promsie for the .then function
//I know its fucking stupid
exports.auth = function(event) {
	return new Promise (function(resolve, reject) {

		//Make sure headers exist
		if (!event.headers.Authorization) {
			reject(401, "Headers not present");
		} else {

			//Parse our basic-auth headers
			//Check database for token authorization
			let { name, pass } = basicAuth.parse(event.headers.Authorization);
			let token = pass; // Because we are really passing a token

			console.log('token', token);
			knex("users")
				.select("id", "username", "access_token", "approverid", "token_expir", "type")
				.where("username", name)
				.where("status", true)
				.whereRaw("token_expir < CURRENT_TIMESTAMP")
				.first()
				.then(function(user) {
					console.log('trying to auth user', user);
					if (!user) {
						console.log("Username not found or Token Expired or Token Wrong");
						reject(403, "Username not found or Token Expired or Token Wrong");
					} else if (user.access_token === token) {
						console.log(user.type, user.username, " successfully authenticated");
						event.user = user;
						resolve(200, "it worked");
					} else {
						console.log("Access_token not right");
						reject(403, "Access_token not right");
					}
				})
				.catch(function(err) {
					console.log("Database query failed", err);
					reject(500, err.message);
				});
		}
	});
};