module.exports = async function (event) {
	return true;
};